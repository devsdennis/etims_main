<?php

return [
    'name' => 'Accounting',
    'module_version' => '0.8',
    'pid' => 16,
];
